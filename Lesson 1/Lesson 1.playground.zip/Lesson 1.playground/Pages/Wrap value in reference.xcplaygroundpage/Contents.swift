//: [Previous](@previous)
let value: Int = 1 // a struct
var copyofvalue = value
copyofvalue.negate()

value
copyofvalue

// Create a new type which encapsulates the value type Int and allows it to be used as a reference type.
//: [Next](@next)
